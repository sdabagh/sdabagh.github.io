// MAT300 Grading Assistant - Content Script
// Runs on Canvas SpeedGrader pages

console.log('MAT300 Grading Assistant content script loaded');

// Add visual indicator that extension is active
function addExtensionIndicator() {
  if (document.getElementById('mat300-indicator')) return;

  const indicator = document.createElement('div');
  indicator.id = 'mat300-indicator';
  indicator.innerHTML = `
    <div style="
      position: fixed;
      top: 10px;
      right: 10px;
      background: linear-gradient(135deg, #2C5F7C, #3A7CA5);
      color: white;
      padding: 8px 16px;
      border-radius: 6px;
      font-size: 12px;
      font-weight: 600;
      z-index: 10000;
      box-shadow: 0 2px 8px rgba(0,0,0,0.2);
      font-family: 'Segoe UI', sans-serif;
    ">
      📊 MAT300 Assistant Active
    </div>
  `;

  document.body.appendChild(indicator);

  // Remove after 3 seconds
  setTimeout(() => {
    indicator.style.transition = 'opacity 0.5s';
    indicator.style.opacity = '0';
    setTimeout(() => indicator.remove(), 500);
  }, 3000);
}

// Run when page loads
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', addExtensionIndicator);
} else {
  addExtensionIndicator();
}

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'extractDiscussion') {
    const data = extractDiscussionData();
    sendResponse({ success: true, data });
    return true;
  }

  if (request.action === 'fillGrading') {
    const success = fillGradingForm(request.gradingData);
    sendResponse({ success });
    return true;
  }
});

// Extract discussion data from Canvas page
function extractDiscussionData() {
  const data = {
    studentName: '',
    discussionTitle: '',
    initialPost: '',
    peerResponses: [],
    timestamps: [],
    postDates: []
  };

  try {
    // Extract student name
    const studentNameEl = document.querySelector('#students_selectmenu-button .ui-selectmenu-item-header, .student_name');
    if (studentNameEl) {
      data.studentName = studentNameEl.textContent.trim();
    }

    // Extract discussion title
    const titleEl = document.querySelector('.discussion-title, h1.discussion_topic_title, .discussion-topic-title');
    if (titleEl) {
      data.discussionTitle = titleEl.textContent.trim();
    }

    // Extract from iframe if present
    const iframe = document.querySelector('#speedgrader_iframe');
    if (iframe && iframe.contentDocument) {
      const iframeDoc = iframe.contentDocument;

      // Look for discussion entries in iframe
      const entries = iframeDoc.querySelectorAll('.discussion_entry, .discussion-entry, .entry, .entry-content');

      entries.forEach((entry, index) => {
        // Get entry content
        const messageEl = entry.querySelector('.message, .entry-content, p');
        if (messageEl) {
          const content = messageEl.textContent.trim();

          // Get timestamp
          const timestampEl = entry.querySelector('.discussion-pubdate, .published, time, .date');
          const timestamp = timestampEl ? timestampEl.textContent.trim() : '';

          if (content) {
            if (index === 0 && !data.initialPost) {
              data.initialPost = content;
              if (timestamp) data.postDates.push(timestamp);
            } else if (content !== data.initialPost) {
              data.peerResponses.push(content);
              if (timestamp) data.postDates.push(timestamp);
            }
          }
        }
      });

      // Fallback: get all text if no entries found
      if (!data.initialPost) {
        const bodyText = iframeDoc.body.textContent.trim();
        if (bodyText.length > 50) {
          data.initialPost = bodyText;
        }
      }
    }

    // Also check main document for discussion content
    if (!data.initialPost) {
      const mainEntries = document.querySelectorAll('.discussion_entry, .discussion-entry, .entry');
      mainEntries.forEach((entry, index) => {
        const messageEl = entry.querySelector('.message, .entry-content');
        if (messageEl) {
          const content = messageEl.textContent.trim();
          if (index === 0) {
            data.initialPost = content;
          } else {
            data.peerResponses.push(content);
          }
        }
      });
    }

  } catch (error) {
    console.error('Error extracting discussion data:', error);
  }

  return data;
}

// Fill Canvas grading form with AI-generated grades
function fillGradingForm(gradingData) {
  try {
    // Fill total score in grade input
    const gradeInput = document.querySelector(
      '#grading-box-extended input[name="submission[score]"], ' +
      '#grade_container input[type="text"], ' +
      'input[name="grade"]'
    );

    if (gradeInput) {
      gradeInput.value = gradingData.totalScore;
      gradeInput.dispatchEvent(new Event('input', { bubbles: true }));
      gradeInput.dispatchEvent(new Event('change', { bubbles: true }));
      gradeInput.dispatchEvent(new Event('blur', { bubbles: true }));
    }

    // Fill feedback comment
    const commentBox = document.querySelector(
      '#speed_grader_comment_textarea, ' +
      '.comment_textarea, ' +
      'textarea[name="comment"]'
    );

    if (commentBox) {
      commentBox.value = gradingData.feedback;
      commentBox.dispatchEvent(new Event('input', { bubbles: true }));
      commentBox.dispatchEvent(new Event('change', { bubbles: true }));
    }

    // Try to fill rubric if available
    const rubricContainer = document.querySelector('.rubric_container, .rubric-assessment');
    if (rubricContainer) {
      console.log('Rubric container found');
      // Rubric filling would need to be customized based on actual Canvas rubric HTML
      // For now, we'll just log that it was found
    }

    return true;

  } catch (error) {
    console.error('Error filling grading form:', error);
    return false;
  }
}

// Highlight grading elements for debugging
function highlightGradingElements() {
  const elements = [
    '#grading-box-extended',
    '#grade_container',
    '#speed_grader_comment_textarea',
    '.rubric_container'
  ];

  elements.forEach(selector => {
    const el = document.querySelector(selector);
    if (el) {
      el.style.border = '2px solid #D97D54';
      console.log(`Found: ${selector}`);
    }
  });
}

// Uncomment to debug
// highlightGradingElements();
