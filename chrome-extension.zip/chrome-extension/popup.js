// MAT300 Grading Assistant - Popup Logic

let currentDiscussion = null;
let currentGrading = null;

// Initialize popup
document.addEventListener('DOMContentLoaded', async () => {
  // Load saved configuration
  await loadConfiguration();

  // Check if we're on a Canvas grading page
  await checkCanvasPage();

  // Set up event listeners
  setupEventListeners();
});

// Load saved API key and worker URL
async function loadConfiguration() {
  const result = await chrome.storage.local.get(['apiKey', 'workerUrl']);

  if (result.apiKey) {
    document.getElementById('api-key').value = result.apiKey;
  }

  if (result.workerUrl) {
    document.getElementById('worker-url').value = result.workerUrl;
  }
}

// Check if we're on a Canvas SpeedGrader page
async function checkCanvasPage() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (tab.url && tab.url.includes('smc.instructure.com') && tab.url.includes('speed_grader')) {
    // Show grading section
    document.getElementById('grading-section').classList.remove('hidden');
  } else {
    // Show message to navigate to Canvas
    const statusDiv = document.getElementById('status-message');
    statusDiv.textContent = '⚠️ Please navigate to a Canvas SpeedGrader page to use grading features';
    statusDiv.className = 'status-message info';
  }
}

// Set up all event listeners
function setupEventListeners() {
  // Configuration buttons
  document.getElementById('save-key').addEventListener('click', saveApiKey);
  document.getElementById('save-url').addEventListener('click', saveWorkerUrl);

  // Grading buttons
  document.getElementById('extract-btn').addEventListener('click', extractDiscussion);
  document.getElementById('grade-btn').addEventListener('click', gradeWithAI);
  document.getElementById('apply-to-canvas').addEventListener('click', applyToCanvas);
  document.getElementById('reset-btn').addEventListener('click', resetGrading);

  // Score dropdowns - update total when changed
  const scoreSelects = document.querySelectorAll('.score-select');
  scoreSelects.forEach(select => {
    select.addEventListener('change', updateTotalScore);
  });
}

// Save API key to storage
async function saveApiKey() {
  const apiKey = document.getElementById('api-key').value.trim();

  if (!apiKey) {
    showStatus('config-status', 'Please enter an API key', 'error');
    return;
  }

  if (!apiKey.startsWith('sk-ant-')) {
    showStatus('config-status', 'Invalid API key format. Should start with "sk-ant-"', 'error');
    return;
  }

  await chrome.storage.local.set({ apiKey });
  showStatus('config-status', '✅ API key saved successfully!', 'success');
}

// Save worker URL to storage
async function saveWorkerUrl() {
  const workerUrl = document.getElementById('worker-url').value.trim();

  if (!workerUrl) {
    showStatus('config-status', 'Please enter a worker URL', 'error');
    return;
  }

  if (!workerUrl.startsWith('https://')) {
    showStatus('config-status', 'Worker URL must start with https://', 'error');
    return;
  }

  await chrome.storage.local.set({ workerUrl });
  showStatus('config-status', '✅ Worker URL saved successfully!', 'success');
}

// Extract discussion content from Canvas
async function extractDiscussion() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    // Inject content script and extract discussion
    const [result] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      function: extractCanvasDiscussion
    });

    if (!result || !result.result) {
      showStatus('status-message', '❌ Failed to extract discussion content', 'error');
      return;
    }

    currentDiscussion = result.result;

    // Update UI with extracted data
    document.getElementById('student-name').textContent = currentDiscussion.studentName || 'Unknown';
    document.getElementById('discussion-title').textContent = currentDiscussion.discussionTitle || 'Unknown Discussion';

    const previewDiv = document.getElementById('discussion-preview');
    previewDiv.innerHTML = `
      <strong>Initial Post:</strong><br>
      ${currentDiscussion.initialPost || 'No initial post found'}<br><br>
      <strong>Peer Responses (${currentDiscussion.peerResponses?.length || 0}):</strong><br>
      ${currentDiscussion.peerResponses?.map((r, i) => `${i + 1}. ${r}`).join('<br><br>') || 'No peer responses found'}
    `;

    // Show grade button
    document.getElementById('grade-btn').classList.remove('hidden');
    showStatus('status-message', '✅ Discussion content extracted successfully!', 'success');

  } catch (error) {
    console.error('Extract error:', error);
    showStatus('status-message', `❌ Error: ${error.message}`, 'error');
  }
}

// Content script function to extract Canvas discussion data
function extractCanvasDiscussion() {
  try {
    const data = {
      studentName: '',
      discussionTitle: '',
      initialPost: '',
      peerResponses: [],
      timestamps: []
    };

    // Extract student name from SpeedGrader header
    const studentNameEl = document.querySelector('#students_selectmenu-button .ui-selectmenu-item-header');
    if (studentNameEl) {
      data.studentName = studentNameEl.textContent.trim();
    }

    // Extract discussion title
    const titleEl = document.querySelector('.discussion-title, h1.discussion_topic_title');
    if (titleEl) {
      data.discussionTitle = titleEl.textContent.trim();
    }

    // Extract discussion entries (initial post and peer responses)
    const entries = document.querySelectorAll('.discussion_entry, .entry');

    entries.forEach((entry, index) => {
      const messageEl = entry.querySelector('.message, .entry-content');
      if (messageEl) {
        const content = messageEl.textContent.trim();

        // Extract timestamp if available
        const timestampEl = entry.querySelector('.discussion-pubdate, .published');
        const timestamp = timestampEl ? timestampEl.textContent.trim() : '';

        if (index === 0) {
          // First entry is typically the initial post
          data.initialPost = content;
        } else {
          // Subsequent entries are peer responses
          data.peerResponses.push(content);
        }

        if (timestamp) {
          data.timestamps.push(timestamp);
        }
      }
    });

    // If no entries found with those selectors, try iframe content
    if (!data.initialPost) {
      const iframe = document.querySelector('#speedgrader_iframe');
      if (iframe && iframe.contentDocument) {
        const iframeBody = iframe.contentDocument.body;
        data.initialPost = iframeBody.textContent.trim();
      }
    }

    return data;

  } catch (error) {
    console.error('Extraction error:', error);
    return null;
  }
}

// Grade discussion using AI
async function gradeWithAI() {
  try {
    // Get configuration
    const config = await chrome.storage.local.get(['apiKey', 'workerUrl']);

    if (!config.apiKey || !config.workerUrl) {
      showStatus('status-message', '❌ Please configure API key and worker URL first', 'error');
      return;
    }

    if (!currentDiscussion) {
      showStatus('status-message', '❌ Please extract discussion content first', 'error');
      return;
    }

    // Show loading state
    document.getElementById('grading-progress').classList.remove('hidden');
    document.getElementById('grade-btn').disabled = true;

    // Call Cloudflare Worker API
    const response = await fetch(config.workerUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        apiKey: config.apiKey,
        discussion: currentDiscussion
      })
    });

    if (!response.ok) {
      throw new Error(`API request failed: ${response.status}`);
    }

    const grading = await response.json();
    currentGrading = grading;

    // Hide loading, show results
    document.getElementById('grading-progress').classList.add('hidden');
    document.getElementById('grading-results').classList.remove('hidden');

    // Populate grading results
    populateGradingResults(grading);

    showStatus('status-message', '✅ AI grading complete! Review and adjust as needed.', 'success');

  } catch (error) {
    console.error('Grading error:', error);
    document.getElementById('grading-progress').classList.add('hidden');
    document.getElementById('grade-btn').disabled = false;
    showStatus('status-message', `❌ Error: ${error.message}`, 'error');
  }
}

// Populate grading results in UI
function populateGradingResults(grading) {
  // Set scores in dropdowns
  document.getElementById('score-initial').value = grading.scores.initialPost;
  document.getElementById('score-peers').value = grading.scores.peerResponses;
  document.getElementById('score-clarity').value = grading.scores.clarity;
  document.getElementById('score-participation').value = grading.scores.participation;
  document.getElementById('score-timeliness').value = grading.scores.timeliness;

  // Set reasoning text
  document.getElementById('reasoning-initial').textContent = grading.reasoning.initialPost;
  document.getElementById('reasoning-peers').textContent = grading.reasoning.peerResponses;
  document.getElementById('reasoning-clarity').textContent = grading.reasoning.clarity;
  document.getElementById('reasoning-participation').textContent = grading.reasoning.participation;
  document.getElementById('reasoning-timeliness').textContent = grading.reasoning.timeliness;

  // Set feedback comment
  document.getElementById('feedback-comment').value = grading.feedbackComment;

  // Update total score
  updateTotalScore();
}

// Update total score display
function updateTotalScore() {
  const initial = parseInt(document.getElementById('score-initial').value) || 0;
  const peers = parseInt(document.getElementById('score-peers').value) || 0;
  const clarity = parseInt(document.getElementById('score-clarity').value) || 0;
  const participation = parseInt(document.getElementById('score-participation').value) || 0;
  const timeliness = parseInt(document.getElementById('score-timeliness').value) || 0;

  const total = initial + peers + clarity + participation + timeliness;
  document.getElementById('total-score').textContent = total;
}

// Apply grades to Canvas
async function applyToCanvas() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    // Get current scores and feedback
    const gradingData = {
      scores: {
        initialPost: parseInt(document.getElementById('score-initial').value),
        peerResponses: parseInt(document.getElementById('score-peers').value),
        clarity: parseInt(document.getElementById('score-clarity').value),
        participation: parseInt(document.getElementById('score-participation').value),
        timeliness: parseInt(document.getElementById('score-timeliness').value)
      },
      feedback: document.getElementById('feedback-comment').value,
      totalScore: parseInt(document.getElementById('total-score').textContent)
    };

    // Inject content script to fill Canvas form
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      function: fillCanvasGradingForm,
      args: [gradingData]
    });

    showStatus('status-message', '✅ Grades applied to Canvas! Please review before submitting.', 'success');

  } catch (error) {
    console.error('Apply error:', error);
    showStatus('status-message', `❌ Error: ${error.message}`, 'error');
  }
}

// Content script function to fill Canvas grading form
function fillCanvasGradingForm(gradingData) {
  try {
    // Fill total score
    const gradeInput = document.querySelector('#grading-box-extended input[name="submission[score]"], #grade_container input[type="text"]');
    if (gradeInput) {
      gradeInput.value = gradingData.totalScore;
      gradeInput.dispatchEvent(new Event('input', { bubbles: true }));
      gradeInput.dispatchEvent(new Event('change', { bubbles: true }));
    }

    // Fill feedback comment
    const commentBox = document.querySelector('#speed_grader_comment_textarea, .comment_textarea');
    if (commentBox) {
      commentBox.value = gradingData.feedback;
      commentBox.dispatchEvent(new Event('input', { bubbles: true }));
      commentBox.dispatchEvent(new Event('change', { bubbles: true }));
    }

    // Try to fill rubric if available
    // This depends on Canvas's rubric structure which varies
    const rubricInputs = document.querySelectorAll('.rubric_container input[type="radio"]');
    if (rubricInputs.length > 0) {
      // Fill rubric automatically if possible
      // This would need to be customized based on actual Canvas rubric HTML
      console.log('Rubric detected but auto-fill not implemented yet');
    }

    return true;
  } catch (error) {
    console.error('Fill form error:', error);
    return false;
  }
}

// Reset grading state
function resetGrading() {
  currentDiscussion = null;
  currentGrading = null;

  document.getElementById('grading-results').classList.add('hidden');
  document.getElementById('grade-btn').classList.add('hidden');
  document.getElementById('grade-btn').disabled = false;
  document.getElementById('discussion-preview').innerHTML = 'Click "Extract Discussion" to load content from Canvas';

  showStatus('status-message', '🔄 Reset complete. Extract a new discussion to grade.', 'info');
}

// Show status message
function showStatus(elementId, message, type = 'info') {
  const statusDiv = document.getElementById(elementId);
  statusDiv.textContent = message;
  statusDiv.className = `status-message ${type}`;

  // Auto-hide after 5 seconds for success/error
  if (type === 'success' || type === 'error') {
    setTimeout(() => {
      statusDiv.textContent = '';
      statusDiv.className = 'status-message';
    }, 5000);
  }
}
